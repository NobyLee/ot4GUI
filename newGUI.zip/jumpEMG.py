# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'jumpWindow.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(541, 417)
        self.horizontalLayout = QHBoxLayout(Dialog)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label = QLabel(Dialog)
        self.label.setObjectName(u"label")
        font = QFont()
        font.setFamily(u"Adobe Heiti Std")
        font.setPointSize(12)
        self.label.setFont(font)

        self.horizontalLayout_2.addWidget(self.label)

        self.horizontalSpacer = QSpacerItem(238, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.plusButton = QPushButton(Dialog)
        self.plusButton.setObjectName(u"plusButton")
        self.plusButton.setFont(font)

        self.horizontalLayout_2.addWidget(self.plusButton)

        self.minusButton = QPushButton(Dialog)
        self.minusButton.setObjectName(u"minusButton")
        self.minusButton.setFont(font)

        self.horizontalLayout_2.addWidget(self.minusButton)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.EMGLayout = QHBoxLayout()
        self.EMGLayout.setObjectName(u"EMGLayout")

        self.verticalLayout.addLayout(self.EMGLayout)

        self.verticalLayout.setStretch(1, 1)

        self.horizontalLayout.addLayout(self.verticalLayout)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("Dialog", u"EMG", None))
        self.plusButton.setText(QCoreApplication.translate("Dialog", u"+", None))
        self.minusButton.setText(QCoreApplication.translate("Dialog", u"-", None))
    # retranslateUi

